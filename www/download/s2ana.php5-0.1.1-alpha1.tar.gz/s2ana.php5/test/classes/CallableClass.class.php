<?php

interface CallableClass
{
    public function call();
}

?>