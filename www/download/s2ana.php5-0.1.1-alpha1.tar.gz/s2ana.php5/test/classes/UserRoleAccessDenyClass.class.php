<?php

class UserRoleAccessDenyClass implements CallableClass
{
    public function call()
    {
        return TRUE;
    }
}

?>