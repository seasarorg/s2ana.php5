<?php

interface AuthComponent
{
    public function call();
}

?>