<?php

class AuthComponentImpl implements AuthComponent
{
    public function call()
    {
        return TRUE;
    }
}

?>